# birthday
Plays "Happy birthday" and "Feliz en tu día" songs with a square waveform. For PIC16F1826
